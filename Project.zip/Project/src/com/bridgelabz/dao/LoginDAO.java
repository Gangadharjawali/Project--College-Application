package com.bridgelabz.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.bridgelabz.model.LoginBean;


public class LoginDAO 
{  
	
	public static int status;
	public static Connection getConnection()
	{
		Connection connection = null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/college","root","root");
		}
		catch(Exception LoginBean)
		{
			System.out.println(LoginBean);
		}
		return connection;
	}

	public static String validate(String email,String pwd){
		boolean status=false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","root");
			
			PreparedStatement ps=con.prepareStatement("select * from user_demo where email=? and pwd=?");
			ps.setString(1,email);
			ps.setString(2,pwd);
			
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			
		
			return rs.getString("firstname");
		}
		
			catch(Exception e){System.out.println(e);
		}
		return "false";
	}
	
	public static String department(String branch) {
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "root");
			System.out.println("connect to db");
			PreparedStatement ps = con.prepareStatement("select * from student_details where branch=?");
			ps.setString(5, branch);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				System.out.println("usn\t" + rs.getString(1));
				System.out.println("Name\t" + rs.getString(2));
				System.out.println("phone_no\t" + rs.getString(3));
				System.out.println("email\t" + rs.getString(4));
				System.out.println("branch\t" +rs.getString(5));
				System.out.println("address\t" +rs.getString(6));
			} else {
				System.out.println("id not found");
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}
	
	
	
	public  int add(String name,String mobileNumber,String password,String email)
	{
		int status=0;
		try {

			Connection con = LoginDAO.getConnection();
			String query = " insert into user_demo (firstname, phone_number, pwd, email)"
				        + " values (?, ?, ?, ?)";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, name);
			pst.setString(2, mobileNumber);			
			pst.setString(3, password);
			pst.setString(4, email);

			int i = pst.executeUpdate();
			if (i != 0) {

				System.out.println("Record has been inserted");

			} else {
				System.out.println("failed to insert");
			}
			pst.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;

	}
	
	
	
	
	public static int AddStudent(LoginBean loginbean)
	{
		int status=0;
		try {

			Connection con = LoginDAO.getConnection();
			PreparedStatement pst = (PreparedStatement) con.prepareStatement("insert into student_details values(?,?,?,?,?,?,?)");
			pst.setString(1, loginbean.getUsn());
			pst.setString(2, loginbean.getPhone_number());	
			pst.setString(3, loginbean.getName());
					
			pst.setString(4, loginbean.getEmail());
			pst.setString(5, loginbean.getBranch());
			pst.setString(6, loginbean.getAddress());
			pst.setInt(7, loginbean.getId());

			int i = pst.executeUpdate();
			if (i != 0) {

				System.out.println("Record has been inserted");

			} else {
				System.out.println("failed to insert");
			}
			pst.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;

	}
	

	
public JSONArray CollectDeptData(String branch,int id){
	System.out.println("connected to DB");
		
		try {
			JSONArray array = new JSONArray();
			Connection con = LoginDAO.getConnection();
			PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from student_details where branch= ? and userid =?");
			pst.setString(1,  branch);
			pst.setInt(2, id);
			
			ResultSet rs = (ResultSet) pst.executeQuery();
		
		
			while (rs.next()) {
				JSONObject object=new JSONObject();
				object.put("usn",rs.getString("usn"));
				object.put("name",rs.getString("firstname"));
				object.put("phone_number",rs.getString("phone_number"));
				object.put("Email",rs.getString("email"));	
				object.put("address",rs.getString("address"));
				array.add(object);
			}
			System.out.println("collect data"+array);
			return array;
		
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}


	public void DeleteStudent(String usn) {

		try {
			Connection con = LoginDAO.getConnection();
			PreparedStatement pst = (PreparedStatement) con
					.prepareStatement("delete from student_details where usn= ?");

			pst.setString(1, usn);
			pst.executeUpdate();
			System.out.println("deleted");
		} catch (Exception e) {
			System.out.println(e);
		}
		return;
	}

	public JSONObject EditDetails(String usn) {
		System.out.println("connected to Edit DB");
		try {
			
			Connection con = LoginDAO.getConnection();
			PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from student_details where usn= ?");
			pst.setString(1,  usn);
			
			ResultSet rs = (ResultSet) pst.executeQuery();
		
			JSONObject object=new JSONObject();
			while (rs.next()) {
				
				object.put("usn",rs.getString("usn"));
				object.put("name",rs.getString("firstname"));
				object.put("phone_number",rs.getString("phone_number"));
				object.put("Email",rs.getString("email"));	
				object.put("address",rs.getString("address"));
				object.put("branch",rs.getString("branch"));
			}	
			System.out.println("edit detail"+object);
			return object;
		
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	public void EditStudent(int usn, String name, String phone_no, String email, String branch, String address) throws SQLException 
	{
		Connection con = LoginDAO.getConnection();
		String query=" UPDATE student_details SET firstname=? , phone_number= ?, email= ?, branch=?, address= ? where usn=?";
		PreparedStatement pst = con.prepareStatement(query);
	
	
		pst.setString(1, name);
		pst.setString(2,  phone_no);
		pst.setString(3, email);
		pst.setString(4,  branch);
		pst.setString(5, address);
		pst.setInt(6, usn);
		
		
		
		pst.executeUpdate();
	
		
	}

	public static int getID(String email, String pwd) {
		// TODO Auto-generated method stub
		boolean status=false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","root");
			
			PreparedStatement ps=con.prepareStatement("select * from user_demo where email=? and pwd=?");
			ps.setString(1,email);
			ps.setString(2,pwd);
			
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			
		
			return rs.getInt("userid");
		}
		
			catch(Exception e){System.out.println(e);
		}
		return 0;
	}

	

}



	
