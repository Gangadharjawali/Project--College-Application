package com.bridgelabz.controller;
import com.bridgelabz.controller.LoginServlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;

import com.bridgelabz.dao.LoginDAO;
@WebServlet("/DeptDetails")
public class DeptDetails extends HttpServlet {
	

	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String branch= request.getParameter("branch");
	int id=LoginServlet.id;
	
	System.out.println("connecter to server");
	LoginDAO college=new LoginDAO();
	JSONArray DeptData = college.CollectDeptData(branch,id);
	PrintWriter out =new PrintWriter(response.getWriter());
	out.println(DeptData.toString());
	out.close();
	}

}