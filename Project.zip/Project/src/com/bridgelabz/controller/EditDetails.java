package com.bridgelabz.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.json.simple.JSONObject;

import com.bridgelabz.dao.LoginDAO;
@WebServlet("/EditDetails")
public class EditDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		
		 String usn= request.getParameter("usn");
		 System.out.println("connected to server\t"+usn);
		LoginDAO college=new LoginDAO();
		JSONObject EditData = college.EditDetails(usn);
		PrintWriter out =new PrintWriter(response.getWriter());
		System.out.println(EditData);
			out.println(EditData.toString());
			
			out.close();
	}
}