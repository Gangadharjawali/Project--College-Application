package com.bridgelabz.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bridgelabz.dao.LoginDAO;
import com.bridgelabz.model.LoginBean;

@WebServlet("/AddDetails")
public class RegisterServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;      
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		System.out.println();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String mobileNumber = request.getParameter("phone_number");
		String email = request.getParameter("email");
		String password = request.getParameter("password");	
		
		System.out.println("get from html");
	
		
		LoginDAO login=new LoginDAO();
		login.add(name,mobileNumber,password,email);
		System.out.println("load into sql,");
	    RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
				rd.include(request,response);
	}

}