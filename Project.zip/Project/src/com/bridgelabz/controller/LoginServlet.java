package com.bridgelabz.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bridgelabz.dao.LoginDAO;

@WebServlet("/servlet1")
public class LoginServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static int id;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		String email=request.getParameter("email");
		String pwd=request.getParameter("password");
		
		
		String name = LoginDAO.validate(email, pwd);
		System.out.println(name);
		if (name!="false") {
			HttpSession session=request.getSession();
			session.setAttribute("name",name);
			response.sendRedirect("dashboard.jsp");
		} else {
			response.sendRedirect("login.jsp");
		}
		
		id=LoginDAO.getID(email,pwd);
		System.out.println(id);
		
		
		/*
		if(LoginDAO.validate(email,pwd)){
			response.sendRedirect("dashboard.jsp");
		}
		else{
			
		    out.println("User or password incorrect");
		    
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.include(request,response);
		}
		
		out.close();*/
		
		 
		
		
	}
}
