package com.bridgelabz.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.bridgelabz.dao.LoginDAO;


@WebServlet("/EditStudentDetails")
public class EditStudentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		int usn=Integer.parseInt(request.getParameter("usn"));
		String name=request.getParameter("name");
		String phone_no=request.getParameter("phone_no");
		String email=request.getParameter("email");
		String branch=request.getParameter("branch");
		String address=request.getParameter("address");
		
		
	
		
		System.out.println("Servlet collected data\t" + usn);
		
		
		LoginDAO student=new LoginDAO();
		try {
			student.EditStudent(usn,name,phone_no,email,branch,address);
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		System.out.println("load into sql,");
	
	   
		
		out.close();
		
		
		
		
	}
}
