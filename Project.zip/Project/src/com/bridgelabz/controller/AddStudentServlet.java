package com.bridgelabz.controller;
import java.io.IOException;
import com.bridgelabz.controller.LoginServlet;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.bridgelabz.dao.LoginDAO;
import com.bridgelabz.model.LoginBean;

@WebServlet("/AddStudentDetails")
public class AddStudentServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String usn=request.getParameter("usn");
		String name=request.getParameter("name");
		String phone_no=request.getParameter("phone_no");
		String email=request.getParameter("email");
		String branch=request.getParameter("branch");
		String address=request.getParameter("address");
		int id=LoginServlet.id;
		
		
		System.out.println("collected id\t"+id);
		
		System.out.println("get from html");
		
		LoginBean loginbean = new LoginBean();
		loginbean.setUsn(usn);
		loginbean.setName(name);
		loginbean.setPhone_number(phone_no);
		loginbean.setEmail(email);
		loginbean.setBranch(branch);
		loginbean.setAddress(address);
		loginbean.setId(id);
		
		LoginDAO student=new LoginDAO();
		student.AddStudent(loginbean);
		System.out.println("load into sql,");
	
	    RequestDispatcher rd=request.getRequestDispatcher("dashboard.jsp");
				rd.include(request,response);
		
		
		
		out.close();
		
		
		
		
	}
}
